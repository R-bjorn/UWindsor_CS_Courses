/**
 * 
 */
package shapes;

import java.awt.Color;
import java.awt.Graphics;

/**
 * @author ravid
 *
 */
public class Triangle extends AtomicShape {

	protected int x, y, width, height;
//	protected Point p1, p2, p3;
	
	// Constructor
	public Triangle(int x, int y, int width, int height, Color color) {
		this.x = x; this.y = y;
		this.width = width;
		this.height = height;
		this.color = color;
	}

	@Override
    public void move(int buttonDownX, int buttonDownY, int newx, int newy, Graphics g) {
    	if (buttonDownX >= this.x && buttonDownX <= this.x + this.width)
    	{
    		if (buttonDownY >= this.y && buttonDownY <= this.y + this.height)
        	{
    			changeCoords(buttonDownX, buttonDownY, newx, newy);
    			this.paint(g);
        	}
    	}
    }
	
	@Override   
    protected void changeCoords(int buttonDownX, int buttonDownY, int newx, int newy) {
		int deltaX = this.x - buttonDownX;
    	int deltaY = this.y - buttonDownY;
    	this.x = newx + deltaX;
    	this.y = newy + deltaY;
    }
    

	@Override
	public void paint(Graphics g) {
		// TODO Auto-generated method stub
//		Graphics2D g2d = (Graphics2D) g;
		int middle = Math.abs(this.height-this.x)/2;
		int [] x = {this.x + middle, this.x, this.width};
        int [] y = {this.y, this.height, this.height};
        g.drawPolygon(x, y, 3);		
	}

	@Override
	public String toString() {
		return "Triangle: " + x + " " + y + " " + width + " " + height;
	}

}
