/**
 * 
 */
package shapes;

import java.awt.Color;

/**
 * @author ravid
 *
 */
public abstract class AtomicShape extends Shape {

	protected Color color;

}
