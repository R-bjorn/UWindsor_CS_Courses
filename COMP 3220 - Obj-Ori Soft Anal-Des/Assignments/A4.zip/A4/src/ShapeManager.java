import java.util.ArrayList;

import javax.swing.JLabel;

import shapes.Shape;

@SuppressWarnings("serial")
public abstract class ShapeManager extends JLabel{
	public ArrayList<Shape> shapes = new ArrayList<Shape>();
	
	public abstract void mergeAll();
	public abstract void unmergeAll();
	
}
